// ---------- Real-Time Object Detection App ----------
// Uses TensorFlow.js + the COCO-SSD pre-trained model.
// Everything runs locally in the browser (on-device AI, no server calls).

const video = document.getElementById("video");
const overlay = document.getElementById("overlay");
const ctx = overlay.getContext("2d");
const statusEl = document.getElementById("status");
const startBtn = document.getElementById("startBtn");
const switchBtn = document.getElementById("switchBtn");
const thresholdSlider = document.getElementById("threshold");
const threshVal = document.getElementById("threshVal");
const detectionList = document.getElementById("detectionList");

let model = null;
let currentStream = null;
let facingMode = "environment"; // back camera by default
let detecting = false;
let confidenceThreshold = 0.5;

const COLORS = [
  "#f87171", "#fbbf24", "#34d399", "#60a5fa",
  "#a78bfa", "#f472b6", "#38bdf8", "#facc15",
];

function colorForClass(className) {
  let hash = 0;
  for (let i = 0; i < className.length; i++) hash = className.charCodeAt(i) + ((hash << 5) - hash);
  return COLORS[Math.abs(hash) % COLORS.length];
}

// ---------- Load the AI model ----------
async function loadModel() {
  statusEl.textContent = "Loading AI model…";
  model = await cocoSsd.load(); // default base model, good balance of speed/accuracy
  statusEl.textContent = "Model loaded. Tap 'Start Camera' to begin.";
  startBtn.disabled = false;
}

// ---------- Camera handling ----------
async function startCamera() {
  stopCamera();
  try {
    currentStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode, width: { ideal: 1280 }, height: { ideal: 960 } },
      audio: false,
    });
    video.srcObject = currentStream;
    await video.play();
    resizeOverlay();
    statusEl.textContent = "Camera running — detecting objects…";
    if (!detecting) {
      detecting = true;
      detectFrame();
    }
  } catch (err) {
    statusEl.textContent = "Camera error: " + err.message;
    console.error(err);
  }
}

function stopCamera() {
  if (currentStream) {
    currentStream.getTracks().forEach((t) => t.stop());
    currentStream = null;
  }
}

function resizeOverlay() {
  overlay.width = video.videoWidth || video.clientWidth;
  overlay.height = video.videoHeight || video.clientHeight;
}

// ---------- Detection loop ----------
async function detectFrame() {
  if (!detecting) return;

  if (model && video.readyState === 4) {
    const predictions = await model.detect(video);
    const filtered = predictions.filter((p) => p.score >= confidenceThreshold);
    drawPredictions(filtered);
    updateDetectionList(filtered);
  }

  requestAnimationFrame(detectFrame);
}

function drawPredictions(predictions) {
  resizeOverlay();
  ctx.clearRect(0, 0, overlay.width, overlay.height);

  predictions.forEach((pred) => {
    const [x, y, width, height] = pred.bbox;
    const color = colorForClass(pred.class);
    const label = `${pred.class} ${(pred.score * 100).toFixed(0)}%`;

    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.strokeRect(x, y, width, height);

    ctx.font = "16px -apple-system, sans-serif";
    const textWidth = ctx.measureText(label).width;
    ctx.fillStyle = color;
    ctx.fillRect(x, Math.max(0, y - 22), textWidth + 12, 22);

    ctx.fillStyle = "#0f172a";
    ctx.fillText(label, x + 6, Math.max(16, y - 6));
  });
}

function updateDetectionList(predictions) {
  detectionList.innerHTML = "";
  if (predictions.length === 0) {
    detectionList.innerHTML = '<li class="empty">No objects detected</li>';
    return;
  }
  predictions
    .sort((a, b) => b.score - a.score)
    .forEach((pred) => {
      const li = document.createElement("li");
      li.innerHTML = `<span>${pred.class}</span><span class="conf">${(pred.score * 100).toFixed(0)}%</span>`;
      detectionList.appendChild(li);
    });
}

// ---------- Controls ----------
startBtn.addEventListener("click", startCamera);

switchBtn.addEventListener("click", () => {
  facingMode = facingMode === "environment" ? "user" : "environment";
  startCamera();
});

thresholdSlider.addEventListener("input", (e) => {
  confidenceThreshold = Number(e.target.value) / 100;
  threshVal.textContent = `${e.target.value}%`;
});

window.addEventListener("resize", resizeOverlay);

// ---------- Init ----------
startBtn.disabled = true;
loadModel();
