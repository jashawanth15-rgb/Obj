# 📷 Real-Time Object Detection App (Phone Camera + AI)

A fully working real-time object detection web app that runs **entirely in the
browser** — including on your phone — using **TensorFlow.js** and the
**COCO-SSD** pre-trained AI model. No backend server, no API keys, no app
store required. Point your phone's camera at things and it draws boxes and
labels around 80 everyday object classes (person, car, dog, phone, bottle,
laptop, etc.) in real time.

## How it works

- `index.html` — page layout: video feed + canvas overlay + controls
- `style.css` — styling
- `app.js` — loads the AI model, accesses the camera, runs detection on every
  video frame, and draws bounding boxes + labels
- The AI model (**COCO-SSD**, built on TensorFlow.js) is loaded from a CDN at
  runtime — you don't need to download or train anything

Because everything runs on-device in the browser, your camera feed **never
leaves your phone** — nothing is uploaded anywhere.

---

## Step 1 — Get the code onto GitHub

1. Unzip the project you downloaded.
2. Go to [github.com/new](https://github.com/new) and create a new repository
   (e.g. `object-detection-app`). Leave it empty (no README/gitignore).
3. On your computer, open a terminal in the unzipped folder and run:

   ```bash
   git init
   git add .
   git commit -m "Initial commit: real-time object detection app"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/object-detection-app.git
   git push -u origin main
   ```

That's it — your code is now on GitHub.

---

## Step 2 — Run it locally on your computer (to test first)

Browsers block camera access on plain `file://` pages, so you need a tiny
local server. Pick one:

**Option A — Python (already installed on most systems):**
```bash
cd object-detection-app
python3 -m http.server 8000
```
Then open `http://localhost:8000` in your browser.

**Option B — Node.js:**
```bash
npx http-server -p 8000
```

**Option C — VS Code:** install the "Live Server" extension, right-click
`index.html` → "Open with Live Server".

Click **Allow** when the browser asks for camera permission. You should see
your webcam feed with live bounding boxes.

---

## Step 3 — Get it running on your phone

You have two easy options:

### Option A: Free hosting with GitHub Pages (recommended — gives you a public link)
1. In your GitHub repo, go to **Settings → Pages**.
2. Under "Build and deployment", set **Source** to `Deploy from a branch`,
   branch `main`, folder `/ (root)`. Click **Save**.
3. Wait ~1 minute, then GitHub will give you a URL like:
   `https://YOUR_USERNAME.github.io/object-detection-app/`
4. Open that URL **on your phone's browser** (Chrome/Safari). Allow camera
   access when prompted. Done — it's live on your phone.

   > Camera access requires HTTPS (except on `localhost`). GitHub Pages
   > serves over HTTPS automatically, so this works out of the box.

### Option B: Same Wi-Fi network (no deployment needed)
1. Run the local server (Step 2) on your computer.
2. Find your computer's local IP address:
   - Mac/Linux: `ifconfig | grep inet`
   - Windows: `ipconfig`
   - Look for something like `192.168.1.42`
3. On your phone (connected to the **same Wi-Fi**), open:
   `http://192.168.1.42:8000`
4. Note: some phone browsers still restrict camera access on non-HTTPS pages
   even on local networks — if it doesn't work, use Option A instead.

---

## Step 4 — Using the app

1. Tap **Start Camera** — grants camera permission and starts the feed.
2. Tap **Switch Camera** to toggle between front/back camera.
3. Drag the **Confidence** slider to control how strict detection is (higher
   = fewer, more confident detections; lower = more detections, more noise).
4. Detected objects appear both as boxes on the video and as a list below it.

---

## Customizing it

- **Change the model:** COCO-SSD has 3 base models — `lite_mobilenet_v2`
  (fastest, default balance), `mobilenet_v1`, `mobilenet_v2` (more accurate,
  slightly slower). Edit `app.js`:
  ```js
  model = await cocoSsd.load({ base: "mobilenet_v2" });
  ```
- **Detect only specific objects:** filter the `predictions` array in
  `detectFrame()` by `pred.class` (e.g. only show `"person"` or `"cell phone"`).
- **Add sound/vibration alerts:** hook into `updateDetectionList()` to trigger
  `navigator.vibrate()` or play a sound when a specific class appears.
- **Swap in a custom-trained model:** if you train your own model (e.g. with
  Teachable Machine or a custom TensorFlow.js model), replace the `cocoSsd.load()`
  call with `tf.loadGraphModel()` pointing at your model's `model.json`.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Camera doesn't start | Make sure you're on `https://` or `localhost` — camera access is blocked on plain HTTP for non-localhost sites |
| Blank/black video | Check that no other app is using the camera; try reloading the page |
| Slow / laggy detection | Use the `lite_mobilenet_v2` base model (default); close other browser tabs; on older phones, try landscape mode for a smaller effective frame |
| "Permission denied" | You may have previously blocked camera access — check your browser's site settings and re-allow |
| Works on desktop but not phone | Confirm you're using an HTTPS URL (GitHub Pages) — most mobile browsers require it |

---

## Tech stack

- [TensorFlow.js](https://www.tensorflow.org/js) — in-browser machine learning
- [COCO-SSD](https://github.com/tensorflow/tfjs-models/tree/master/coco-ssd) —
  pre-trained object detection model (80 object classes from the COCO dataset)
- Vanilla HTML/CSS/JS — no build step, no framework required

## License

Free to use, modify, and distribute for any purpose.
